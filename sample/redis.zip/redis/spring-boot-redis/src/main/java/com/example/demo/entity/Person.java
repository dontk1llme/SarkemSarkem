package com.example.demo.entity;

import java.util.List;

public class Person {

	String id;
	String name;
	int age;
	
	List<String> tag;
	
}
