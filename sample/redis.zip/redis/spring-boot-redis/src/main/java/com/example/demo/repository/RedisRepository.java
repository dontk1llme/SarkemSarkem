package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.entity.Person;

public interface RedisRepository extends CrudRepository<Person, String> {

}
